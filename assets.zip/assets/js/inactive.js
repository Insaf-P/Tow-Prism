var ourClientDiv = document.getElementById("our-clientele-section");
var testimonial = document.getElementById("testimonial-section");
var Subscribe = document.getElementById("Subscribe");


ourClientDiv.style.display = "none";
testimonial.style.display = "none";
Subscribe.style.display = "none";

